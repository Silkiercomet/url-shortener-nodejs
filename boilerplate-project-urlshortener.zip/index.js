require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();
const dns = require('dns');
const { writeFile, readFile } = require('fs');

// Basic Configuration
const port = process.env.PORT || 3000;
app.use(express.json());
app.use(cors());

app.use(express.urlencoded({ extended: true }))
const path = "./urls.json"

const URL = require('url').URL

function validateUrl(urlString) {
  try {
    new URL(urlString)
    return true
  } catch {
    return false
  }
} 

const middlewarePost = (req, res, next) => {
  let url = req.body.url
  let isValid = validateUrl(url) && /^(http|https):\/\/[^ "]+$/.test(url);


  if(isValid === true  ){
    req.validUrl = url
    next()
    return
  }

  res.json({ error: 'invalid url' })

}

app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function(req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

app.post('/api/shorturl',middlewarePost, function(req, res){
  let newUrl = {}
    readFile(path, (error, data) => {
      if (error) {
        console.log(error);
        return;
      }
      let parsedData = JSON.parse(data);
      newUrl = {original_url:req.validUrl,short_url:parsedData.urls.length+1}
      parsedData.urls = [...parsedData.urls,newUrl ]
      writeFile(path, JSON.stringify(parsedData, null, 2), (err) => {
    if (err) {
      console.log('Failed to write updated data to file');
      return;
    }
    console.log('Updated file successfully');
    res.json(newUrl)
  });
    })
            
      

})

app.get('/api/shorturl/:url', (req,res) => {
  readFile(path, (error, data) => {
      if (error) {
        console.log(error);
        return;
      }
      let parsedData = JSON.parse(data);
      let newUrl = parsedData.urls.find(e => e.short_url == req.params["url"])
    
      res.redirect(newUrl.original_url)
  })

})

// Your first API endpoint
app.get('/api/hello', function(req, res) {
  res.json({ greeting: 'hello API' });
});

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});
